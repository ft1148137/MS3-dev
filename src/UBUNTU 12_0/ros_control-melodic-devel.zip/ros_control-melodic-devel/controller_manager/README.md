## Controller Manager ##

The `controller_manager` provides a hard-realtime-compatible loop to control a robot mechanism, as well as
infrastructure to load, unload, start and stop controllers. 

Detailed user documentation can be found in the package's [ROS wiki page](http://wiki.ros.org/controller_manager).

